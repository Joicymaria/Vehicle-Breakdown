<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if(isset($_POST['submit']))
{
    $name = $_POST['name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    $sql = "INSERT INTO tblcontact(Name, Email, Subject, Message) VALUES(:name, :email, :subject, :message)";
    $query = $dbh->prepare($sql);
    $query->bindParam(':name', $name, PDO::PARAM_STR);
    $query->bindParam(':email', $email, PDO::PARAM_STR);
    $query->bindParam(':subject', $subject, PDO::PARAM_STR);
    $query->bindParam(':message', $message, PDO::PARAM_STR);
    $query->execute();

    $lastInsertId = $dbh->lastInsertId();
    if ($lastInsertId) {
        echo "<script>alert('Your message has been sent successfully.');</script>";
        echo "<script>window.location.href = 'contact.php';</script>";
    } else {
        echo "<script>alert('Something went wrong. Please try again.');</script>";
    }

}
?>
<!DOCTYPE html>
<html class="no-js" lang="zxx">
<head>
    <!-- Basic page needs
    ============================================ -->
    <title>Contact Us || Tinker</title>

    <!-- ============== All CSS ================ -->
    <link rel="stylesheet" href="css1/normalize.css">
    <link rel="stylesheet" href="css1/animate.css">
    <link rel="stylesheet" href="css1/bootstrap.min.css">
    <link rel="stylesheet" href="css1/meanmenu.min.css">
    <link rel="stylesheet" href="css1/font-awesome.min.css">
    <link rel="stylesheet" href="css1/icofont.css">
    <link rel="stylesheet" href="css1/change-text.css">
    <link rel="stylesheet" href="css1/jquery.mb.YTPlayer.min.css">
    <link rel="stylesheet" href="css1/main.css">
    <link rel="stylesheet" href="css1/owl.carousel.css">
    <link rel="stylesheet" href="css1/owl.theme.css">
    <link rel="stylesheet" href="css1/owl.transitions.css">
    <link rel="stylesheet" href="lib/css/nivo-slider.css">
    <link rel="stylesheet" href="lib/css/preview.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css1/responsive.css">
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>
</head>
<body>
    <!--[if lt IE 8]>
    <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->

    <?php include_once('includes/header.php');?>

    <!-- page title area start -->
    <div class="page-title-area overlay">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!-- page title start -->
                    <div class="page-title">
                        <h2>Contact Us</h2>
                    </div>
                    <!-- page title end -->
                    <!-- page title menu start -->
                    <div class="page-title-menu">
                        <ul>
                            <li><a href="index.php">Home</a> <span> / </span> </li>
                            <li><a href="contact.php">Contact Us</a></li>
                        </ul>
                    </div>
                    <!-- page title menu end -->
                </div>
            </div>
        </div>
    </div>
    <!-- page title area end -->

    <!-- contact form area start -->
    <div class="contact-form-area">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2 col-xs-12">
                    <!-- contact box start -->
                    <div class="contact-box spacer">
                        <!-- contact info start -->
                        <div class="contact-info">
                            <?php
                            $sql="SELECT * from tblpage where PageType='contactus'";
                            $query = $dbh -> prepare($sql);
                            $query->execute();
                            $results=$query->fetchAll(PDO::FETCH_OBJ);

                            if($query->rowCount() > 0)
                            {
                                foreach($results as $row)
                                { 
                            ?>
                            <!-- title -->
                            <h3 class="contact-title">Contact Address</h3>
                            <!-- single address start -->
                            <div class="single-address">
                                <div class="icon"><i class="icofont icofont-location-pin"></i></div>
                                <div class="icon-text">
                                    <p><?php echo htmlentities($row->PageDescription);?></p>
                                </div>
                            </div>
                            <!-- single address end -->
                            <!-- single address start -->
                            <div class="single-address">
                                <div class="icon"><i class="icofont icofont-phone"></i></div>
                                <div class="icon-text">
                                    <p>Phone : +<?php echo htmlentities($row->MobileNumber);?></p>
                                </div>
                            </div>
                            <!-- single address end -->
                            <!-- single address start -->
                            <div class="single-address">
                                <div class="icon"><i class="icofont icofont-envelope"></i></div>
                                <div class="icon-text">
                                    <p><?php echo htmlentities($row->Email);?> </p>
                                </div>
                            </div>
                            <!-- single address end -->
                        </div>
                        <?php 
                            }
                        }
                        ?>
                        <!-- contact info end -->

                        <!-- contact form start -->
                        <?php if(isset($msg)){ ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo htmlentities($msg); ?>
                            </div>
                        <?php } else if(isset($error)){ ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo htmlentities($error); ?>
                            </div>
                        <?php } ?>
                        <form action="" method="post">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="name">Name</label>
                                        <input type="text" name="name" id="name" class="form-control" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="email">Email</label>
                                        <input type="email" name="email" id="email" class="form-control" required>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="subject">Subject</label>
                                <input type="text" name="subject" id="subject" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="message">Message</label>
                                <textarea name="message" id="message" rows="5" class="form-control" required></textarea>
                            </div>
                            <div class="form-group text-center">
                                <div class="form-btn">
                                    <div class="shopping-button">
                                        <div class="form-btn">
                                            <button class="submit-btn"  name="submit">Send Message</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </form>
                        <!-- contact form end -->
                    </div>
                    <!-- contact box end -->
                </div>
            </div>
        </div>
    </div>
    <!-- contact form area end -->

    <?php include_once('includes/footer.php');?>

    <!-- ============== All JS ================ -->
    <script src="js/vendor/jquery-1.12.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.meanmenu.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/change-text.js"></script>
    <script src="js/jquery.mb.YTPlayer.min.js"></script>
    <script src="js/jquery.lettering.js"></script>
    <script src="js/jquery.textillate.js"></script>
    <script src="lib/js/jquery.nivo.slider.js"></script>
    <script src="lib/home.js"></script>
    <script src="js/ajax-mail.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
