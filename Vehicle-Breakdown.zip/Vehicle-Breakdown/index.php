<?php
session_start();
error_reporting(0);

include('includes/dbconnection.php');
?>
<!DOCTYPE html>
<html class="no-js" lang="zxx">
    <head>
        <title>VBAMS || Home Page </title>
        
        <!-- ============== All CSS ================ -->
        <link rel="stylesheet" href="css1/normalize.css">
        <link rel="stylesheet" href="css1/animate.css">
        <link rel="stylesheet" href="css1/bootstrap.min.css">
        <link rel="stylesheet" href="css1/meanmenu.min.css">
        <link rel="stylesheet" href="css1/font-awesome.min.css">
        <link rel="stylesheet" href="css1/icofont.css">
        <link rel="stylesheet" href="css1/change-text.css">
        <link rel="stylesheet" href="css1/jquery.mb.YTPlayer.min.css">
        <link rel="stylesheet" href="css1/main.css">
        <link rel="stylesheet" href="css1/owl.carousel.css">
        <link rel="stylesheet" href="css1/owl.theme.css">
        <link rel="stylesheet" href="css1/owl.transitions.css">
        <link rel="stylesheet" href="lib/css/nivo-slider.css">
        <link rel="stylesheet" href="lib/css/preview.css">
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="css1/responsive.css">
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
        <style>
            /* Hide the navigation buttons */
            .nivo-directionNav a {
                display: none !important;
            }
        </style>
    </head>
    <body>
        <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

       <?php include_once('includes/header.php'); ?>
        
        <!-- slider area start -->
        <div class="slider-area">
            <div class="bend niceties preview-1">
                <!-- slider images start -->
                <div id="nivoslider" class="slides">
                    <img src="img1/slider/towing2.jpg" alt="slider_2" title="#slider-direction-2"/>
                </div>
                <!-- slider images end -->
                <!-- slider 1 direction -->
                <div id="slider-direction-1" class="t-cn slider-direction">
                    <!-- slider progress start -->
                    <div class="slider-progress"></div>
                    <!-- slider progress end -->
                </div>
                <!-- slider 2 direction -->
                <div id="slider-direction-2" class="t-cn slider-direction">
                    <!-- slider progress start -->
                    <div class="slider-progress"></div>
                    <!-- slider progress end -->
                    <!-- slider caption start -->
                    <div class="slider-caption">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-9">
                                    <!-- layer 1 -->
                                    <div class="layer-1-1">
                                        <h2 class="title-1">Best Vehicle Breakdown  </h2>
                                    </div>
                                    <!-- layer 2 -->
                                    <div class="layer-1-2">
                                        <h2 class="title-2"> Assistance Management System </h2>
                                    </div>
                                    <!-- layer 3 -->
                                    <div class="layer-2-3">
                                        <p class="title-3">Our system provides swift and reliable breakdown assistance for all vehicle types. Whether you need towing, fuel delivery, or any other roadside service, we are here to help you 24/7. Trust us to get you back on the road safely and quickly.</p>
                                    </div>
                                    <!-- layer 4 -->
                                    <div class="layer-2-4">
                                        <a href="booking-request.php" class="title-4">Book Now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- slider caption end -->
                </div>
            </div>
        </div>
        <!-- slider area end -->

        <!-- about us area start -->
        <div class="about-us-area section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <!-- section title start -->
                        <div class="section-heading">
                            <h2>About <span>Us</span></h2>
                        </div>
                        <!-- section title end -->
                        <!-- about content start -->
                        <div class="about-us-info">
                             <?php
                                $sql="SELECT * from tblpage where PageType='aboutus'";
                                $query = $dbh -> prepare($sql);
                                $query->execute();
                                $results=$query->fetchAll(PDO::FETCH_OBJ);

                                $cnt=1;
                                if($query->rowCount() > 0)
                                {
                                foreach($results as $row)
                                {               
                            ?>
                            <p><?php  echo htmlentities($row->PageDescription);?></p>
                            
                            <?php $cnt=$cnt+1;}} ?>
                        </div>
                        <!-- about content end -->
                    </div>
                    <div class="col-md-6 hidden-xs">
                        <!-- about us img start -->
                        <div class="about-us-img">
                            <img src="img1/about/tow-truck-federal-way-2.jpg" alt="">
                        </div>
                        <!-- about us img end -->
                    </div>
                </div>
            </div>
        </div>
        <!-- about us area end -->
      
        <?php include_once('includes/footer.php'); ?>

        <!-- ============== All JS ================ -->
        <script src="js/vendor/jquery-1.12.0.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.meanmenu.js"></script>
        <script src="js/jquery.scrollUp.min.js"></script>
        <script src="js/wow.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/change-text.js"></script>
        <script src="js/jquery.mb.YTPlayer.min.js"></script>
        <script src="js/jquery.lettering.js"></script>
        <script src="js/jquery.textillate.js"></script>
        <script src="lib/js/jquery.nivo.slider.js"></script>
        <script src="lib/home.js"></script>
        <script src="js/plugins.js"></script>
        <script src="js/main.js"></script>
    </body>
</html>
